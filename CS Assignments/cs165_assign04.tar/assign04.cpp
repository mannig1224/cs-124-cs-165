/***************************************************************
 * File: assign04.cpp
 * Author: Emmanuel Gatica
 * Purpose: Contains the main function to test the Product class.
 ***************************************************************/

#include <iostream>
#include <string>
using namespace std;

#include "product.h"

void secondChoice();

int main()
{
   // Declare your Product object here
   Product productObject;


   // Call your prompt function here
   productObject.prompt();




   cout << endl;
   cout << "Choose from the following options:\n";
   cout << "1 - Advertising profile\n";
   cout << "2 - Inventory line item\n";
   cout << "3 - Receipt\n";
   cout << endl;
   cout << "Enter the option that you would like displayed: ";

   int choice;
   cin >> choice;
   cin.ignore();

   cout << endl;

   if (choice == 1)
   {
      productObject.displayOne();

   }
   else if (choice == 2)
   {
      // Call your display inventory line item function here
      productObject.displayTwo();
      /*
      cout << "And one more: ";
      cout << endl;
      secondChoice();
      */
   }
   else
   {
      // Call your display receipt function here
      productObject.displayThree();
   }

   return 0;
}

void secondChoice()
{
  // Declare your Product object here
  Product productSecond;

  // Call your prompt function here
  productSecond.prompt();

  cout << endl;
  cout << "Choose from the following options:\n";
  cout << "1 - Advertising profile\n";
  cout << "2 - Inventory line item\n";
  cout << "3 - Receipt\n";
  cout << endl;
  cout << "Enter the option that you would like displayed: ";
  int choice;
  cin >> choice;
  cin.ignore();

  cout << endl;

  if (choice == 1)
  {
     productSecond.displayOne();
  }
  else if (choice == 2)
  {
     // Call your display inventory line item function here
     productSecond.displayTwo();
  }
  else
  {
     // Call your display receipt function here
     productSecond.displayThree();
  }
}
