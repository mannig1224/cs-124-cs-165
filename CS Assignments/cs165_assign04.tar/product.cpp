/***************************************************************
 * File: product.cpp
 * Author: Emmanuel Gatica
 * Purpose: Contains the method implementations for the Product class.
 ***************************************************************/

#include "product.h"
#include <string>
#include <iostream>
#include <iomanip>      // std::setw

using namespace std;

// put your method bodies here

/*************************************************************
 * Product :: set()
 *
 * Prompts for the name, base price, weight, and description,
 * and sets these values in the current object
 *************************************************************/
void Product :: prompt()
{
   cout << "Enter name: ";
   getline(cin, name);
   cout << "Enter description: ";
   getline(cin, description);
   cout << "Enter weight: ";
   cin >> weight;
   cin.ignore();
   bool isBadPrice;

   do
   {
     isBadPrice = false;

     cout << "Enter price: ";
     cin >> price;

        if(cin.fail() || price < 0)
        {
          isBadPrice = true;
          cin.clear();
          cin.ignore(256, '\n');
        }
   }
   while(isBadPrice);
}

/*************************************************************
 * Product :: getSalesTax()
 *
 * Returns 6% of the base price
 *************************************************************/
float Product :: getSalesTax()
{
   float tax;
   tax = price * .06;
   return tax;
}

/*************************************************************
 * Product :: getShippingCost()
 *
 * Returns a flat rate of $2.00 if the item is less than 5 lbs,
 * and $2.00 + $0.10 per pound over 5 lbs
 *************************************************************/
float Product :: getShippingCost()
{
  float rate;
   if (weight < 5)
   {
     rate = 2.00;
   }
   else
   {
     int overFive;
     overFive = weight - 5;
     rate = 2.00 + .10 * overFive;
   }
   return rate;
}

/*************************************************************
 * Product :: getTotalPrice()
 *
 * Uses other methods to return a total price.
 *************************************************************/
float Product :: getTotalPrice()
{
   float rate = getShippingCost();
   float tax = getSalesTax();
   float total;
   total = total + price + rate + tax;
   return total;
}

/*************************************************************
 * Product :: displayOne()
 *
 * displays first option.
 *************************************************************/
void Product :: displayOne()
{
   cout << name << " - $" << price << endl << "("
      << description << ")" << endl;
}

/*************************************************************
 * Product :: displayTwo()
 *
 * displays second option.
 *************************************************************/
void Product :: displayTwo()
{
   cout << "$" << price << " - " << name << " - " << weight << " lbs";
   cout << endl;
}

/*************************************************************
 * Product :: displayThree()
 *
 * displays third option.
 *************************************************************/
void Product :: displayThree()
{
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   cout << name << endl;
   cout << "  Price:         $" << setw(8) << price << endl;
   cout << "  Sales tax:     $" << setw(8) << getSalesTax() << endl;
   cout << "  Shipping cost: $" << setw(8) << getShippingCost() << endl;
   cout << "  Total:         $" << setw(8) << getTotalPrice() << endl;
}
