/***************************************************************
 * File: product.h
 * Author: Emmanuel Gatica
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H

// put your class definition here
#include <iostream>
#include <string>
using namespace std;
/*************************************
 * Product Class:
 * Stores a Product Info
 *************************************/
class Product
{
   private:
      string name;
      float price;
      float weight;
      string description;

   public:
      void prompt();
      float getSalesTax();
      float getShippingCost();
      float getTotalPrice();
      void displayOne();
      void displayTwo();
      void displayThree();

 };



#endif
