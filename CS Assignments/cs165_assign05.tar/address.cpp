/***************************************************************
 * File: address.cpp
 * Author: Emmanuel Gatica
 * Purpose: Contains the method implementations for the address class
 ***************************************************************/

#include "address.h"
#include <string>
#include <iostream>

using namespace std;

// put your method bodies here
void Address :: display()
{
   cout << street << endl;
   cout << city << ", " << state << " " << zip;
   cout << endl;
};
