/***************************************************************
 * File: address.h
 * Author: Emmanuel Gatica
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef ADDRESS_H
#define ADDRESS_H

// put your class definition here
#include <iostream>
#include <string>
using namespace std;
/*************************************
 * Address Class:
 * Stores an Address
 *************************************/
class Address
{
   private:
      string street;
      string city;
      string state;
      string zip;


   public:
     string getStreet() const {return street; }
     string getCity()   const {return city; }
     string getState()  const {return state; }
     string getZip()    const {return zip; }

     void setStreet (string street) {this->street = street;}
     void setCity(string city){this->city = city;}
     void setState (string state){this->state = state;}
     void setZip(string zip){this->zip = zip;}
     void display();

     Address()
     {
        street = "unknown";
        zip    = "00000"  ;
        state  = ""       ;
        city   = ""       ;
     }

     Address(string street, string city, string state, string zip)
     {
        setStreet(street);
        setCity(city);
        setState(state);
        setZip(zip);
     }


 };



#endif
