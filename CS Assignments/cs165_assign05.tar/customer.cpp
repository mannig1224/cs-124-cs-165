// File: customer.cpp

#include "address.h"
#include "customer.h"

// Put the method bodies for your customer class here
void Customer :: display()
{
  cout << name << endl;
  address.display();

};
