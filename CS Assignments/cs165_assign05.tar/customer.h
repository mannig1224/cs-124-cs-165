/***************************************************************
 * File: customer.h
 * Author: Emmanuel Gatica
 * Purpose: Contains the definition of the customer class
 ***************************************************************/
#ifndef CUSTOMER_H
#define CUSTOMER_H


// put your class definition here
#include <iostream>
#include <string>
using namespace std;

#include "address.h"
/*************************************
 * Customer Class:
 * Stores customer info.
 *************************************/
class Customer
{
   private:
      string name;
      Address address;


   public:
     string getName()       const {return name;}
     Address getAddress()   const {return address;}

     void setName(string name){this->name = name;}
     void setAddress(Address address) {this->address = address;}

     void display();

     Customer()
     {
        name = "unspecified";
     }

     Customer(string name, Address address)
     {
       setName(name);
       setAddress(address);
     }


 };



#endif
