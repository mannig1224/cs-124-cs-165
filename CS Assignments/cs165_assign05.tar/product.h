/***************************************************************
 * File: product.h
 * Author: Emmanuel Gatica
 * Purpose: Contains the definition of the Product class
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H

// put your class definition here
#include <iostream>
#include <string>
using namespace std;
/*************************************
 * Product Class:
 * Stores a Product Info
 *************************************/
class Product
{
   private:
      string name;
      float price;
      float weight;
      string description;

   public:
      void prompt();
      string getName() const {return name; }
      string getDescription() const {return description; }
      float getWeight() const {return weight; }
      float getPrice() const {return price; }

      void setName (string name){this->name = name;}
      void setDescription(string description){this->description = description;}
      void setWeight (float weight){this->weight = weight;}
      void setPrice(float price){this->price = price;}

      float getSalesTax();
      float getShippingCost();
      float getTotalPrice();

      void displayAdvertising();
      void displayInventory();
      void displayReceipt();

      Product()
      {
         name           = "none";
         description    = "";
         weight         = 0 ;
         price          = 0 ;
      }
      Product(string name, string description, float price, float weight)
      {
         setName(name);
         setDescription(description);
         setWeight(weight);
         setPrice(price);
      }

 };



#endif
