/***********************************************************************
* Program:
*    Checkpoint 04b, Classes
*    Brother Alvey, CS165
* Author:
*    Emmanuel Gatica
* Summary:
*    Summaries are not necessary for checkpoint assignments.
* ***********************************************************************/

#include <iostream>
#include <string>
using namespace std;

#include "date.h"

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   Date dateObject;
   dateObject.set();
   cout << endl;
   dateObject.displayAmerican();
   dateObject.displayEuropean();
   dateObject.displayISO();

  return 0;
}
