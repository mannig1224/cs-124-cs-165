/***************************************************************
 * File: date.cpp
 * Author: Emmanuel Gatica
 * Purpose: Contains the method implementations for the date class.
 ***************************************************************/

#include "date.h"
#include <string>
#include <iostream>
using namespace std;

/*************************************************************
 * Date :: set()
 *
 * prompts the users for the date
 *************************************************************/
void Date :: set()
{
   cout << "Month: ";
   getline(cin, month);
   cout << "Day: ";
   getline(cin, day);
   cout << "Year: ";
   getline(cin, year);
}

/*************************************************************
 * Date :: displayAmerican()
 *
 * Displays American Date
 *************************************************************/
void Date :: displayAmerican()
{
   cout << month << "/" << day << "/" << year;
   cout << endl;
}

/*************************************************************
 * Date :: displayEuropean()
 *
 * Displays European Date
 *************************************************************/
void Date :: displayEuropean()
{
   cout << day << "/" << month << "/" << year;
   cout << endl;
}

/*************************************************************
 * Date :: displayIOS()
 *
 * Displays European Date
 *************************************************************/
void Date :: displayISO()
{
   cout << year << "-" << month << "-" << day;
   cout << endl;
}
