/***************************************************************
 * File: date.h
 * Author: Emmanuel Gatica
 * Purpose: Contains the definition of the Rational class
 ***************************************************************/
#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>
using namespace std;
/*************************************
 * Date Class
 *
 * Stores a date
 *************************************/
class Date
{
   private:
      string month;
      string day;
      string year;

   public:
      void set();
      void displayAmerican();
      void displayEuropean();
      void displayISO();

 };


#endif
