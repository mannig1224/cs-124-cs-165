/***********************
 * File: money.cpp
 ***********************/

#include <iostream>
#include <iomanip>
using namespace std;

#include "money.h"

/*****************************************************************
 * Function: prompt
 * Purpose: Asks the user for values for dollars and cents
 *   and stores them.
 ****************************************************************/
void Money :: prompt()
{
   int dollars;
   int cents;

   cout << "Dollars: ";
   cin >> dollars;
   if (dollars < 0 )
   {
     dollars = dollars * -1;
   }

   cout << "Cents: ";
   cin >> cents;
   cin.ignore();
   if (cents < 0 )
   {
     cents = cents * -1;
   }

   setDollars(dollars);
   setCents(cents);
}

int Money :: getDollars() const
{
  return dollars;
}
int Money :: getCents()
{
  return cents;
}

void Money :: setDollars (int _dollars)
{
  dollars = _dollars;
}

void Money :: setCents(int _cents)
{
  cents = _cents;
}


/*****************************************************************
 * Function: display
 * Purpose: Displays the value of the money object.
 ****************************************************************/
void Money :: display()
{
   cout << "$" << getDollars() << ".";
   cout << setfill('0') << setw(2) << getCents();
}
