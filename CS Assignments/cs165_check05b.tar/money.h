/******************
 * File: money.h
 ******************/
#ifndef MONEY_H
#define MONEY_H

class Money
{
private:
   int dollars;
   int cents;


public:
   void prompt() ;
   void display() ;

   int getDollars() const ;
   int getCents()  ;
   void setDollars (int dollars)  ;
   void setCents(int cents) ;
   Money()
   {
      dollars = 0;
      cents = 0;
   }
   Money(int x)
   {
      dollars = x;
      cents = 0;
   }
   Money(int x, int y)
   {
     dollars = x;
     cents = y;
   }
};

#endif
