/*******************
 * smartphone.cpp
 *******************/
#include "smartphone.h"
#include <iostream>

using namespace std;
// TODO: Put your smartphone class methods here...
void SmartPhone::prompt()
{
   promptNumber();
   cout << "Email: ";
   cin >> email;
   cin.ignore();

}
void SmartPhone::displaySmart()
{
   display();
   cout << email << endl;
}
