/*************************************************************
 * File: lander.cpp
 * Author: Emmanuel Gatica
 *
 * Description: Contains the implementations of the
 *  method bodies for the game class.
 *************************************************************/

#include "lander.h"
#include "uiDraw.h"

void Lander::applyGravity(float amount)
{

  velocity.setDy(velocity.getDy() - amount);

}

void Lander::applyThrustLeft()
{
  // if canThrust? add thrust to Velocity

  // consume fuel at this point
}

void Lander::applyThrustRight()
{
  // opposite of Left
}

void Lander::applyThrustBottom()
{
  // velocity fun
  // fuel fun
}

void Lander::advance()
{
  std::cout << "advance\n";
  point.addX(getVelocity().getDx()); // get direction from Velocity
  point.addY(getVelocity().getDy()); // get direction from Velocity
}

bool Lander::canThrust()
{
  return (isAlive() && !isLanded() && fuel > 0);
}

void Lander::draw() const
{
  if (isAlive())
  {
    drawLander(point);
  }
}
