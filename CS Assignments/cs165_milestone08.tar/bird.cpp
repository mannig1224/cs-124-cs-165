
#include "bird.h"

void Bird:: advance()
{
  point.setX(point.getX() + velocity.getDx());
  point.setY(point.getY() + velocity.getDy());

}

int Bird :: hit()
{
  if (!alive)
  {
      return 0;
  }

  life = life - 1;
  if (life <= 0)
  {
    kill();
    return reward;
  }
  else
  {
    return 1;
  }
};
