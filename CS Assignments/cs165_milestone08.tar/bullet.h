#include "flyingObject.h"
#include "uiDraw.h"

#ifndef BULLET_H
#define BULLET_H


class Bullet: public FlyingObject
{
   protected:
      float angle;
   public:
      void fire(Point point, float angle);
      void draw();
      Bullet()
      {
         alive = true;
      };
};
#endif
