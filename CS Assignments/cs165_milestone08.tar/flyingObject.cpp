/* flyingObject.cpp */
#include "flyingObject.h"

void FlyingObject::advance()
{
      point.addX(velocity.getDx());
      point.addY(velocity.getDy());
}
