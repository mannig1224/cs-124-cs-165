
#include "standard.h"

void Standard :: draw()
{
  drawCircle(point, 15);
};
