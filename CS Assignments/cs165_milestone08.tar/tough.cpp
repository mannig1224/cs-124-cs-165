
#include "tough.h"

void Tough :: draw()
{
  drawToughBird(point, 15, getLife());
};
