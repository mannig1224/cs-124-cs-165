/*************************************************************
 * File: lander.h
 * Author: Emmanuel Gatica
 *
 * Description: Contains the definition of the game class.
 *
 *************************************************************/

#ifndef LANDER_H
#define LANDER_H

#include "point.h"
#include "velocity.h"

#define DEFAULT_FUEL 500
#include <stdlib.h>
/*****************************************
 * GAME
 * The main game class containing all the state
 *****************************************/
class Lander
{
   private:
     Point point;
     Velocity velocity;
     bool alive;
     bool landed;
     int fuel;

   public:
     Lander() :  alive(true), landed(false), fuel(DEFAULT_FUEL)
     {
         int x = rand() % 400 - 200;
         int y = rand() % 100 + 100;
         point.setX(x);
         point.setY(y);
     }

     Point getPoint() const { return point; }
     Velocity getVelocity() const { return velocity; }

     bool isAlive() const { return alive; }
     bool isLanded() const { return landed; }
     int getFuel() const { return fuel; }

     void setLanded(bool landed) { this->landed = landed; }
     void setAlive(bool alive) { this->alive = alive; }
     void setFuel(int fuel) {this->fuel = fuel; }

     void applyGravity(float amount);
     void applyThrustLeft();
     void applyThrustRight();
     void applyThrustBottom();

     void advance();

     bool canThrust();

     void draw() const;



};

#endif
