/*************************************************************
 * File: velocity.cpp
 * Author: Emmanuel Gatica
 *
 * Description: Contains the implementations of the
 *  method bodies for the game class.
 *************************************************************/

#include "velocity.h"
