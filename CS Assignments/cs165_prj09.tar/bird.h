#include "flyingObject.h"
#include "uiDraw.h"
#include <stdio.h>
#ifndef BIRD_H
#define BIRD_H


class Bird: public FlyingObject
{
   protected:
      int reward;
      int life;

   public:
      int getReward(){return reward;}
      int getLife(){return life;}
    void advance();
      void setReward(int reward) {this->reward = reward; }
      void setLife(int life) {this->life = life; }
      virtual ~Bird(){}
      int hit();

      Bird()
      : FlyingObject()
      {
      }

};
#endif
