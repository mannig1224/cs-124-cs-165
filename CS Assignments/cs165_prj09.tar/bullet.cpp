#include "bullet.h"
#include "uiDraw.h"
#include <cmath>

#define BULLET_SPEED 10.0

void Bullet :: fire(Point point, float angle)
{
  this->point = point;
  float dx = BULLET_SPEED * (-cos(M_PI / 180.0 * angle));
  float dy = BULLET_SPEED * (sin(M_PI / 180.0 * angle));
  velocity.setDx(dx);
  velocity.setDy(dy);
};
void Bullet :: draw()
{
  drawDot(point);
}
