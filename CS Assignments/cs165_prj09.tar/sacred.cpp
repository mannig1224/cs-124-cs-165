#include "sacred.h"

void Sacred :: draw()
{
  drawSacredBird(point, 15);
};
