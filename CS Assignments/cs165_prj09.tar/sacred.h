#include "bird.h"
#include "flyingObject.h"
#include "uiDraw.h"
#include <stdlib.h>

class Sacred : public Bird
{
public:
      ~Sacred(){ }
      Sacred()
      : Bird()
      {
         velocity.setDx(1);
         velocity.setDy(0);
         point.setX(-200);
         point.setY(rand() % 400 - 200);
         setReward(-10);
         setLife(1);
         alive = true;
          velocity.setDx(rand() % 4 + 3); //3 to 6
          velocity.setDy(rand() % 5); //0 to 4
          if (point.getY() > 0)
          {
              velocity.setDy(velocity.getDy()-4); //-4 to 0
          }

      };
    void draw();

};
