#include "bird.h"
#include "flyingObject.h"
#include "uiDraw.h"
#include <stdlib.h>

class Tough : public Bird
{
public:
      ~Tough(){ }
      Tough()
      : Bird()
      {
         velocity.setDx(1);
         velocity.setDy(0);
         point.setX(-200);
         point.setY(rand() % 400 - 200);
         setReward(3);
         setLife(3);
         alive = true;
          velocity.setDx(rand() % 3 + 2); //3 to 6
          velocity.setDy(rand() % 4); //0 to 4
          if (point.getY() > 0)
          {
              velocity.setDy(velocity.getDy()-3); //-4 to 0
          }

      };
    void draw();

};
